def fahr_to_kelv(temp):

    kelvin = 5. / 9. * (temp - 32.) + 273.15

    return kelvin
